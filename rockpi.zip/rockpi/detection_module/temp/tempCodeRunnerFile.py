        # if theta1_list[0] != None and theta2_list[0] != None:
        #     if 100<theta2_list[0]<130:
        #         print("")